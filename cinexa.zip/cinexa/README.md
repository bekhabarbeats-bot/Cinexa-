# Cinexa

Anime streaming PWA jisme videos device pe hi (IndexedDB) store hote hain — koi backend nahi chahiye.

## Chalane ka tarika (local test)

Service worker sirf `https://` ya `localhost` pe kaam karta hai, seedhe file khol ke nahi. Isliye ek simple local server chalao is folder ke andar:

```bash
python3 -m http.server 8080
```

Phir browser mein kholo: `http://localhost:8080`

Mobile pe "Add to Home Screen" karke install kar sakte ho (Chrome/Edge pe automatically install prompt aayega).

## Real hosting (taaki phone pe kahin se bhi khule)

Kisi bhi static host pe daal do — poora `cinexa/` folder as-is upload karna hai:
- Netlify / Vercel (drag-and-drop deploy)
- GitHub Pages
- Cloudflare Pages

HTTPS zaroori hai PWA install aur service worker ke liye — ye sab hosts free mein HTTPS dete hain.

## Structure

```
cinexa/
  index.html      – home / browse page
  upload.html     – anime + episode upload form
  player.html     – video player + episode list
  manifest.json   – PWA install config
  sw.js           – offline app-shell caching
  css/style.css   – design system
  js/db.js        – IndexedDB layer (anime + episodes stores)
  js/app.js       – home page logic
  js/upload.js    – upload form logic
  js/player.js    – player logic
  icons/          – app icons (192px, 512px)
```

## Abhi ke liye

- "Trending" row pe demo entries hain (placeholder, click karne pe kuch nahi hoga) — inhe hata sakte ho `js/app.js` mein `DEMO_ANIME` array se.
- Upload kiya hua video is browser ke IndexedDB mein save hota hai — dusre device/browser pe nahi dikhega. Agar sab users ko same library dikhani hai to ek backend (server + database) add karna padega; abhi ke liye ye purely on-device hai jaisa tumne bola tha ki upload baad mein add karoge.
- Video file size IndexedDB storage quota ke andar honi chahiye (browser aur device pe depend karta hai, generally kaafi GBs milte hain).
