// db.js — a tiny IndexedDB layer for Cinexa.
// Two stores: "anime" (series metadata) and "episodes" (per-episode video blobs).

const CinexaDB = (() => {
  const DB_NAME = "cinexa-db";
  const DB_VERSION = 1;
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains("anime")) {
          const animeStore = db.createObjectStore("anime", { keyPath: "id" });
          animeStore.createIndex("byGenre", "genre", { unique: false });
        }
        if (!db.objectStoreNames.contains("episodes")) {
          const epStore = db.createObjectStore("episodes", { keyPath: "id" });
          epStore.createIndex("byAnime", "animeId", { unique: false });
        }
      };

      req.onsuccess = (e) => resolve(e.target.result);
      req.onerror = (e) => reject(e.target.error);
    });
    return dbPromise;
  }

  function tx(storeName, mode) {
    return open().then((db) => db.transaction(storeName, mode).objectStore(storeName));
  }

  function uid() {
    return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
  }

  async function addAnime(anime) {
    const store = await tx("anime", "readwrite");
    const record = { id: uid(), createdAt: Date.now(), ...anime };
    return new Promise((resolve, reject) => {
      const req = store.add(record);
      req.onsuccess = () => resolve(record);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function getAllAnime() {
    const store = await tx("anime", "readonly");
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result.sort((a, b) => b.createdAt - a.createdAt));
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function getAnime(id) {
    const store = await tx("anime", "readonly");
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function deleteAnime(id) {
    const animeStore = await tx("anime", "readwrite");
    animeStore.delete(id);
    const eps = await getEpisodes(id);
    const epStore = await tx("episodes", "readwrite");
    eps.forEach((ep) => epStore.delete(ep.id));
  }

  async function addEpisode(animeId, episode) {
    const store = await tx("episodes", "readwrite");
    const record = { id: uid(), animeId, createdAt: Date.now(), ...episode };
    return new Promise((resolve, reject) => {
      const req = store.add(record);
      req.onsuccess = () => resolve(record);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function getEpisodes(animeId) {
    const store = await tx("episodes", "readonly");
    const index = store.index("byAnime");
    return new Promise((resolve, reject) => {
      const req = index.getAll(animeId);
      req.onsuccess = () => resolve(req.result.sort((a, b) => a.epNumber - b.epNumber));
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function getEpisode(id) {
    const store = await tx("episodes", "readonly");
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  return { addAnime, getAllAnime, getAnime, deleteAnime, addEpisode, getEpisodes, getEpisode };
})();
