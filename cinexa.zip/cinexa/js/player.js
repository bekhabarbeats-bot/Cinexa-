// player.js

const params = new URLSearchParams(window.location.search);
const animeId = params.get("anime");
const videoEl = document.getElementById("videoEl");
let currentEpisodeId = params.get("ep");
let currentObjectUrl = null;
let currentEpisodes = [];
let currentAnime = null;

function formatDuration(sec) {
  if (!sec || !isFinite(sec)) return "";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

function saveProgress(episode, progressPercent) {
  let history = [];
  try { history = JSON.parse(localStorage.getItem("cinexa_history") || "[]"); } catch (e) {}
  history = history.filter((h) => h.episodeId !== episode.id);
  history.unshift({
    animeId: currentAnime.id,
    title: currentAnime.title,
    episodeId: episode.id,
    epNumber: episode.epNumber,
    progress: progressPercent,
  });
  localStorage.setItem("cinexa_history", JSON.stringify(history.slice(0, 20)));
}

function renderEpisodeList(activeId) {
  const list = document.getElementById("epList");
  list.innerHTML = "";
  currentEpisodes.forEach((ep) => {
    const row = document.createElement("div");
    row.className = "ep-item" + (ep.id === activeId ? " playing" : "");
    row.tabIndex = 0;
    row.innerHTML = `
      <span class="ep-num">EP ${String(ep.epNumber).padStart(2, "0")}</span>
      <span class="ep-name">${ep.title}</span>
      <span class="ep-dur">${formatDuration(ep.durationSeconds)}</span>
    `;
    row.addEventListener("click", () => playEpisode(ep.id));
    list.appendChild(row);
  });
}

async function playEpisode(episodeId) {
  const ep = currentEpisodes.find((e) => e.id === episodeId);
  if (!ep) return;

  if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
  currentObjectUrl = URL.createObjectURL(ep.videoBlob);
  videoEl.src = currentObjectUrl;
  videoEl.play().catch(() => {});
  currentEpisodeId = episodeId;

  document.getElementById("animeMeta").textContent =
    `${currentAnime.genre || "Uncategorised"} · Episode ${ep.epNumber} of ${currentEpisodes.length}`;

  renderEpisodeList(episodeId);
  history.replaceState(null, "", `player.html?anime=${currentAnime.id}&ep=${episodeId}`);

  videoEl.ontimeupdate = () => {
    if (videoEl.duration) {
      saveProgress(ep, (videoEl.currentTime / videoEl.duration) * 100);
    }
  };

  videoEl.onended = () => {
    const idx = currentEpisodes.findIndex((e) => e.id === episodeId);
    const next = currentEpisodes[idx + 1];
    if (next) playEpisode(next.id);
  };
}

(async function init() {
  if (!animeId) {
    document.getElementById("animeTitle").textContent = "Anime nahi mila";
    return;
  }

  currentAnime = await CinexaDB.getAnime(animeId);
  if (!currentAnime) {
    document.getElementById("animeTitle").textContent = "Anime nahi mila";
    return;
  }

  document.getElementById("animeTitle").textContent = currentAnime.title;
  currentEpisodes = await CinexaDB.getEpisodes(animeId);

  if (currentEpisodes.length === 0) {
    document.getElementById("animeMeta").textContent = "Is anime mein abhi koi episode nahi hai.";
    return;
  }

  const startEpisode = currentEpisodes.find((e) => e.id === currentEpisodeId) || currentEpisodes[0];
  playEpisode(startEpisode.id);
})();
