// app.js — home page

const POSTER_GRADIENTS = [
  "linear-gradient(160deg,#3a1f3d,#17131F)",
  "linear-gradient(160deg,#1f2f3d,#17131F)",
  "linear-gradient(160deg,#3d1f28,#17131F)",
  "linear-gradient(160deg,#233d2a,#17131F)",
  "linear-gradient(160deg,#3d3a1f,#17131F)",
];

const DEMO_ANIME = [
  { title: "Ronin Frequency", genre: "Action", year: 2024, eps: 12 },
  { title: "Glass Garden Diaries", genre: "Slice of Life", year: 2023, eps: 24 },
  { title: "Ashfall Chronicles", genre: "Fantasy", year: 2025, eps: 16 },
  { title: "Neon Shrine", genre: "Sci-Fi", year: 2022, eps: 10 },
  { title: "Paper Lantern Girls", genre: "Drama", year: 2024, eps: 13 },
];

function gradientFor(seed) {
  let h = 0;
  for (const ch of String(seed)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return POSTER_GRADIENTS[h % POSTER_GRADIENTS.length];
}

function showToast(msg) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}

function makeCard({ title, meta, glyph, epBadge, seed, onClick }) {
  const card = document.createElement("div");
  card.className = "card";
  card.tabIndex = 0;
  card.innerHTML = `
    <div class="card-poster" style="--poster-grad:${gradientFor(seed)}">
      <span class="card-glyph">${glyph}</span>
      ${epBadge ? `<span class="card-ep-badge">${epBadge}</span>` : ""}
    </div>
    <div class="card-title">${title}</div>
    <div class="card-meta">${meta}</div>
  `;
  card.addEventListener("click", onClick);
  card.addEventListener("keydown", (e) => { if (e.key === "Enter") onClick(); });
  return card;
}

function renderDemoRow() {
  const row = document.getElementById("demoRow");
  row.innerHTML = "";
  DEMO_ANIME.forEach((a) => {
    row.appendChild(makeCard({
      title: a.title,
      meta: `${a.genre} · ${a.year}`,
      glyph: a.title[0],
      epBadge: `EP ${String(a.eps).padStart(2, "0")}`,
      seed: a.title,
      onClick: () => showToast("Demo entry — apna anime upload karke dekho!"),
    }));
  });
}

async function renderUploadsRow() {
  const row = document.getElementById("uploadsRow");
  const countEl = document.getElementById("uploadsCount");
  const section = document.getElementById("uploadsSection");
  const list = await CinexaDB.getAllAnime();

  if (list.length === 0) {
    countEl.textContent = "";
    row.innerHTML = `<div class="empty-row">Abhi tak kuch upload nahi hua. <a href="upload.html">Pehla anime upload karo →</a></div>`;
    return;
  }

  countEl.textContent = `(${list.length})`;
  row.innerHTML = "";
  for (const a of list) {
    const eps = await CinexaDB.getEpisodes(a.id);
    row.appendChild(makeCard({
      title: a.title,
      meta: `${a.genre || "Uncategorised"} · ${eps.length} ep`,
      glyph: a.title[0],
      epBadge: eps.length ? `EP ${String(eps.length).padStart(2, "0")}` : "0 EP",
      seed: a.id,
      onClick: () => { window.location.href = `player.html?anime=${a.id}`; },
    }));
  }
}

function renderContinueRow() {
  const section = document.getElementById("continueSection");
  const row = document.getElementById("continueRow");
  let history = [];
  try { history = JSON.parse(localStorage.getItem("cinexa_history") || "[]"); } catch (e) {}

  if (!history.length) { section.style.display = "none"; return; }
  section.style.display = "block";
  row.innerHTML = "";
  history.slice(0, 10).forEach((h) => {
    row.appendChild(makeCard({
      title: h.title,
      meta: `Ep ${h.epNumber} · ${Math.round(h.progress || 0)}% dekha`,
      glyph: h.title[0],
      epBadge: `EP ${String(h.epNumber).padStart(2, "0")}`,
      seed: h.animeId,
      onClick: () => { window.location.href = `player.html?anime=${h.animeId}&ep=${h.episodeId}`; },
    }));
  });
}

function animateTapeCounter() {
  const el = document.getElementById("tapeCount");
  let seconds = 0;
  setInterval(() => {
    seconds += 1;
    const h = String(Math.floor(seconds / 3600)).padStart(2, "0");
    const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    el.textContent = `${h}:${m}:${s}`;
  }, 1000);
}

function wireSearch() {
  const input = document.getElementById("searchInput");
  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    document.querySelectorAll(".row-scroll .card").forEach((card) => {
      const title = card.querySelector(".card-title").textContent.toLowerCase();
      card.style.display = q && !title.includes(q) ? "none" : "";
    });
  });
}

(async function init() {
  renderDemoRow();
  renderContinueRow();
  await renderUploadsRow();
  animateTapeCounter();
  wireSearch();
})();
