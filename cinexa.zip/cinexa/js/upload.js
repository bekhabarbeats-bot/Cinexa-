// upload.js

let drafts = []; // { file, title, durationSeconds }

function showToast(msg) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}

function formatDuration(sec) {
  if (!sec || !isFinite(sec)) return "--:--";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

function readDuration(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.src = url;
    v.onloadedmetadata = () => {
      resolve(v.duration);
      URL.revokeObjectURL(url);
    };
    v.onerror = () => resolve(0);
  });
}

function renderDrafts() {
  const list = document.getElementById("epDraftList");
  const dropzone = document.getElementById("dropzone");
  const label = document.getElementById("dropzoneLabel");

  dropzone.classList.toggle("has-file", drafts.length > 0);
  label.textContent = drafts.length
    ? `${drafts.length} episode file chuna gaya — aur add karne ke liye tap karo`
    : "Video file(s) yahan tap karke chuno (MP4, WebM...)";

  list.innerHTML = "";
  drafts.forEach((d, i) => {
    const row = document.createElement("div");
    row.className = "ep-draft";
    row.innerHTML = `
      <span class="ep-num">EP ${String(i + 1).padStart(2, "0")}</span>
      <span>${d.title} · ${formatDuration(d.durationSeconds)}</span>
      <button type="button" class="remove" data-i="${i}">Hatao</button>
    `;
    list.appendChild(row);
  });

  list.querySelectorAll(".remove").forEach((btn) => {
    btn.addEventListener("click", () => {
      drafts.splice(Number(btn.dataset.i), 1);
      renderDrafts();
    });
  });
}

document.getElementById("fileInput").addEventListener("change", async (e) => {
  const files = Array.from(e.target.files || []);
  for (const file of files) {
    const durationSeconds = await readDuration(file);
    drafts.push({ file, title: `Episode ${drafts.length + 1}`, durationSeconds });
  }
  renderDrafts();
  e.target.value = "";
});

document.getElementById("uploadForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const title = document.getElementById("titleInput").value.trim();
  if (!title) return;
  if (drafts.length === 0) {
    showToast("Kam se kam ek episode video add karo");
    return;
  }

  const submitBtn = e.target.querySelector("button[type=submit]");
  submitBtn.disabled = true;
  submitBtn.textContent = "Publish ho raha hai...";

  try {
    const anime = await CinexaDB.addAnime({
      title,
      genre: document.getElementById("genreInput").value,
      synopsis: document.getElementById("synopsisInput").value.trim(),
    });

    for (let i = 0; i < drafts.length; i++) {
      const d = drafts[i];
      await CinexaDB.addEpisode(anime.id, {
        epNumber: i + 1,
        title: d.title,
        durationSeconds: d.durationSeconds,
        videoBlob: d.file,
      });
    }

    showToast("Publish ho gaya!");
    setTimeout(() => { window.location.href = `player.html?anime=${anime.id}`; }, 700);
  } catch (err) {
    console.error(err);
    showToast("Kuch galat ho gaya, dobara try karo");
    submitBtn.disabled = false;
    submitBtn.textContent = "Library mein publish karo";
  }
});

renderDrafts();
